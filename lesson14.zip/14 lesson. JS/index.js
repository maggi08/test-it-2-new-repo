// alert('Hello')

// alert('What is Your name')

// alert('JS - javascript')

// ;aldskjfl;jk sal;fjk satisfies;


console.log(2 - 90 * 79) // asfs;adljf;lasjdkf

console.log(111);

/*

  asdf;kasdnf 
  a sdflk jadskl;f j

  asdfl' jasd;lf 
  asdf asd


  
  */
console.log(222);

let sayHello = 'hello'

const myName = 'Magzhan'

let name = 'Name 1'

let let1 = ''
const const1 = ''
// new newWord = 'new word'
// in
// of

// camelCase
let myVariableIsTwo = 2

// snakeCase
let my_variable_is_two = 2

let CONTANT_WORDS = [
  'new', 'in', ''
]
