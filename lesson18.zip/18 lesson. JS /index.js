// ||, && ->  '', false, NaN, undefined, null, 0


// ?? undefined, null


// let age = prompt('Enter you age:')
// age = +age
// // age = age || '- not entered age'
// age = age ?? '- not entered age'
// alert('Your age is ' + age)
// age = Number(age)
// age = parseInt(age)

// if (age) {
//   alert('Your age is ' + age)
// } else {
//   alert('You do not entered age')
// }



// while, for
// console.log(1);
// console.log(2);
// console.log(3);
// 0 - > 100
// conQ



// let i = 0
// do {
//   i++
//   console.log(i);
// } while (i < 5)

//  i+=2 -> i = i + 2
// for (let i = 10; i > 0; i -= 3) {
//   console.log(i);
// }

// let sum = 0

// while (true) {
//   let number = prompt('Enter a number')
//   if (!number || !Number(number)) break

//   number = +number
//   // sum = sum + number  // -> sum = sum + number
//   sum += number  // -> sum = sum + number
// }

// console.log('sum', sum);


// for (let i = 0; i < 10; i++) {
//   if (i % 2 === 0) continue
//   console.log(i);
// }