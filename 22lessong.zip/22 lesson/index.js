// let obj = {
//     name: 'Magzhan',
//     surename: 'Mussaiyn',
//     age: 24,
//     email: 'email@gmail.com'
// }

// console.log(obj);


// let obj = {}
// obj.newProperty = 'hello world'

let str  = 'hello'
// str.newProperty = 'world'

// console.log('str', str);
// console.log('str.newProperty', str.newProperty);

let str2 = str.toUpperCase()
// console.log('str', str);
// console.log('str2', str2);
// console.log('str2', str2.toLowerCase());



// console.log(NaN == NaN) // 
// console.log(NaN === NaN) // 
// console.log(isNaN(NaN)) // true
// console.log(isNaN('не число' / 2)) // false
// console.log(isFinite(1/0)) // false

// console.log(isFinite(Infinity));
// console.log(isFinite(123));
// console.log(isFinite(1/0));
let num = parseInt('123')

// console.log(num, typeof num);
// console.log(parseInt('asdf123')); // NaN
// console.log(parseInt('213 asdfk')); // NaN
// console.log(parseInt('213.55')); // 213

// console.log(parseFloat('1.03')); // 1.03
// console.log(parseFloat('asd1.03')); // NaN
// console.log(parseFloat('1.03asd')); // NaN


let bigNumber = 143.212
// console.log(bigNumber.toFixed(1));
// console.log(bigNumber.toFixed(5));



// console.log(Math.round(3.4)); // 3 
// console.log(Math.round(3.6)); // 4
// console.log(Math.round(3.5)); // 4


// console.log(Math.floor(3.4)); // 3
// console.log(Math.floor(3.6)); // 3
// console.log(Math.floor(4.9)); // 4


// console.log(Math.trunc(3.4)); // 3
// console.log(Math.trunc(3.6)); // 3
// console.log(Math.trunc(4.9)); // 4


// console.log(Math.ceil(3.001)); // 4
// console.log(Math.ceil(3.4)); // 4
// console.log(Math.ceil(3.6)); // 4
// console.log(Math.ceil(4.9)); // 5

// console.log(0.1 + 0.2 ); // 0.3 